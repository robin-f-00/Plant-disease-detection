# Plant-disease-detection
Our this project is a mini project for improving and enhancing our knowledge about AI in various field. 

For Program to execute please install cv2 using : pip install opencv-python opencv-python-headless
