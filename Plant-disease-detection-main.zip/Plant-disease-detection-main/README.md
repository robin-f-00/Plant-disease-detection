# Plant-disease-detection
Our this project is a mini project for improving and enhancing our knowledge about AI in various field. 
